#include <stdio.h>
int main()
{
    int a;
    printf("enter any number:\n");
    scanf("%d",&a);
    if(a>0){
        printf("positive number");
    }
    else{
        printf("negative number");
    }
    return 0;
}
