#include <stdio.h>

int main()
{
    char name[10];
    char surname[10];
    printf("Enter your name :");
    scanf("%s",&name);

    printf("Enter your surname :");
    scanf("%s",&surname);

    int unit,id;
    float money = 0.0;
    printf("Enter your ID :");
    scanf("%d",&id);

    printf("Enter the obtained unit :");
    scanf("%d",&unit);
    printf("\n");

    if(unit>=0 && unit<200)
    {
    printf("You will be charged @1.20 charge/unit.\n");
    money=unit*1.20;
    }

    else if(unit>=200 && unit<=400){
        printf("You will be charged @1.50 charge/unit.\n");
        money=unit*1.50;
    }
    else if(unit>400 && unit<=600){
        printf("You will be charged @1.50 charge/unit.\n");
        money=unit*1.80;
    }
    else if(unit>600){
        printf("You will be charged @2.00 charge/unit.\n");
        money=unit*2.00;
    }

    else{
        printf("Invalid");
    }


    printf("________________________________________________________\n");
    printf("|");   printf("Name : %s %s",name,surname); printf("|\n");
    printf("|");   printf("ID   : %d",id);              printf("|\n");
    printf("|");   printf("Obtained Unit : %d ",unit);  printf("|\n");
    printf("|");   printf("Total charged :%f ",money);  printf("|\n");
    printf("________________________________________________________\n");



































    return 0;
}
