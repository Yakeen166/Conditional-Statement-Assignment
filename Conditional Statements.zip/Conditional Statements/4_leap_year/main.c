#include <stdio.h>

int main()
{
   int num;
   printf("Enter the year!\n");
   scanf("%d",&num);

   if(num%400==0)
       printf("It is a leap year!\n");

   else if(num%4 ==0&& num%100!=0)
       printf("It is a leap year!\n");
    else
       printf("It is not a leap year!\n");





    return 0;
}
