#include <stdio.h>

int main()
{
    int num;
    printf("Enter the value of m:\n");
    scanf("%d",&num);

    if (num>0)
        printf("The value of m is 1.\n");
    else if (num<0)
        printf("The value of m is -1.\n");
    else
        printf("The value of m is 0.\n");





    return 0;

}
