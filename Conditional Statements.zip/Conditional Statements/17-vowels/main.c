#include <stdio.h>

int main()
{
    char alphabet;

    printf("Enter the alphabet:");
    scanf("%c",&alphabet);

    if(alphabet=='a' || alphabet=='e' || alphabet=='i' || alphabet=='o' || alphabet=='u')
        printf("The given alphabet is a Vowel.");
    else
        printf("The given alphabet is a Consonant.");

    return 0;
}
