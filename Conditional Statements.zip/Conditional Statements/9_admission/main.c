#include <stdio.h>

int main()
{

    int maths,phy,chem;
    printf("What did you scored in Maths?  \n");
    scanf("%d",&maths);

    printf("What did you scored in Physics?  \n");
    scanf("%d",&phy);

    printf("What did you scored in Chemistry?  \n");
    scanf("%d",&chem);

    if (maths>=65 && phy>=55 && chem>=50 &&  maths + chem + phy>=180 &&  maths + chem || phy>=140)
        printf("You can get Admission.\n");
    else
        printf("Sorry! Work Hard. Future are in your Hands.\n");



    return 0;
}
