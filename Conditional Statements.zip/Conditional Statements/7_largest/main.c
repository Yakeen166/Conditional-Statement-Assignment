#include <stdio.h>

int main()
{
    int a,b,c;

 /* for(int i=1 ; i<=3 ; i++)
  {
  printf("Enter the num %d:\t",i);
  scanf("%d",&num);
  }
  */

    printf("Enter the num a:");
    scanf("%d",&a);

    printf("Enter the num b:");
    scanf("%d",&b);

    printf("Enter the num c:");
    scanf("%d",&c);

    if(a>b && a>c)
        printf("The largest number is a : %d\n",a);

    else if(b>c && b>a)
        printf("The largest number is b : %d\n",b);

    else if(c>a && c>b)
        printf("The largest number is c : %d\n",c);






    return 0;
}
