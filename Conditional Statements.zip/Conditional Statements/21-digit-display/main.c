#include <stdio.h>
int main()
{
    int digits;
    printf("Enter any single digit:");
    scanf("%d",&digits);
    printf("\n");
    printf("The entered digit %d in word is : ",digits);
    switch(digits){
        case 1:
            printf("One\n");
            break;
        case 2:
            printf("Two\n");
            break;
        case 3:
            printf("Three\n");
            break;
        case 4:
            printf("Four\n");
            break;
        case 5:
            printf("Five\n");
            break;
        case 6:
            printf("Six\n");
            break;
        case 7:
            printf("Seven\n");
            break;
        case 8:
            printf("Eight\n");
            break;
         case 9:
            printf("Nine\n");
            break;
        default:
            printf("Enter valid digit\n");
    }
    return 0;
}
