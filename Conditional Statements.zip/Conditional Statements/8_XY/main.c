#include <stdio.h>

int main()
{

    int x,y;
    int quadrant;

    printf("Enter the coordinate of x: ");
    scanf("%d",&x);

    printf("Enter the coordinate of y: ");
    scanf("%d",&y);

    if (x>0 && y>0)
    {
        quadrant=1;
    }

   else if (x<0 && y>0)
    {
        quadrant = 2;

    }


    else if (x<0 && y<0)
        quadrant = 3;

    else if (x>0 && y<0)
        quadrant = 3;

    printf("The coordinate (x,y)=(%d,%d) lies in %d Quadrant.\n",x,y,quadrant);




    return 0;
}
