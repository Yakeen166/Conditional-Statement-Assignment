#include <stdio.h>

int main()
{
    int side1,side2,side3;

    printf("Enter the length of first side of the triangle:");
    scanf("%d",&side1);

    printf("Enter the length of second side of the triangle:");
    scanf("%d",&side2);

    printf("Enter the length of third side of the triangle:");
    scanf("%d",&side3);

    if(side1 == side2 == side3)
        printf("The given triangle is equilateral.\n");
    else if(side1==side2 || side2==side3 || side1==side3)
            printf("The given triangle is Isosceles.\n");
    else if(side1 != side2!= side3)
        printf("The given triangle is Scalane.\n");


    return 0;
}
