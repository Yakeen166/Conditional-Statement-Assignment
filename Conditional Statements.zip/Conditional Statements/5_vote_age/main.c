#include <stdio.h>

int main()
{
    int age;
    printf("Enter your age:\n");
    scanf("%d",&age);

    if (age>=18)
        printf("You can vote now.\n");

    else
        printf("You can't vote.\n");


    return 0;
}
